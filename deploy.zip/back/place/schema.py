import re, requests
import graphene
from django.conf import settings
from django.core.management import call_command
from graphene_django import DjangoObjectType

from back.place.models import (
  Category, CategoryLog,
  RegionName, RegionLog,
  PlaceInfo, PlaceLog
)

from serpapi import GoogleSearch

# 🔑 외부 API 설정
DEEPL_URL = 'https://api-free.deepl.com/v2/translate'
DEEPL_AUTH_KEY = settings.DEEPL_API_KEY


# ---------------------------
# 🔍 DeepL 번역 함수
# ---------------------------
def deepl_translate(text: str, source_lang: str, target_lang: str) -> str:
  try:
    res = requests.post(
      DEEPL_URL,
      data={
        'text': text,
        'source_lang': source_lang,
        'target_lang': target_lang,
        'auth_key': DEEPL_AUTH_KEY,
      }
    )
    res.raise_for_status()
    return res.json()['translations'][0]['text']
  except Exception as e:
    raise RuntimeError(f'DeepL translation failed: {str(e)}')


# ---------------------------
# 📦 GraphQL 타입 정의
# ---------------------------
class CategoryType(DjangoObjectType):
  class Meta:
    model = Category

class RegionNameType(DjangoObjectType):
  class Meta:
    model = RegionName

class PlaceInfoType(DjangoObjectType):
  class Meta:
    model = PlaceInfo


# ---------------------------
# 📘 카테고리 번역
# ---------------------------
class TranslateCategory(graphene.Mutation):
  class Arguments:
    text = graphene.String(required=True)

  translated_text = graphene.String()

  def mutate(self, info, text):
    if not text:
      raise Exception("Missing 'text' field")

    CategoryLog.objects.create(korean=text)

    try:
      category = Category.objects.get(korean=text)
      return TranslateCategory(translated_text=category.english)
    except Category.DoesNotExist:
      pass

    translated = deepl_translate(text, source_lang='KO', target_lang='EN')
    Category.objects.create(korean=text, english=translated)
    return TranslateCategory(translated_text=translated)


# ---------------------------
# 🗺️ 지역명 번역
# ---------------------------
class TranslateRegionToKorean(graphene.Mutation):
  class Arguments:
    text = graphene.String(required=True)

  translated_text = graphene.String()

  def mutate(self, info, text):
    if not text:
      raise Exception("Missing 'text' field")

    RegionLog.objects.create(english=text)

    try:
      region = RegionName.objects.get(english=text)
      return TranslateRegionToKorean(translated_text=region.korean)
    except RegionName.DoesNotExist:
      pass

    translated = deepl_translate(text, source_lang='EN', target_lang='KO')
    RegionName.objects.create(korean=translated, english=text)
    return TranslateRegionToKorean(translated_text=translated)


# ---------------------------
# 🧭 장소 정보 조회 및 저장
# ---------------------------
class GetPlaceInfo(graphene.Mutation):
  class Arguments:
    name = graphene.String(required=True)
    address = graphene.String(required=True)

  place = graphene.Field(PlaceInfoType)

  def mutate(self, info, name, address):
    if not name or not address:
      raise Exception('Missing name or address')

    PlaceLog.objects.create(name=name, address=address)

    try:
      place = PlaceInfo.objects.get(name=name, address=address)
      return GetPlaceInfo(place=place)

    except PlaceInfo.DoesNotExist:
      query = f"{name} {address}"
      params = {
        "engine": "google",
        "q": query,
        "type": "search",
        "google_domain": "google.co.kr",
        "hl": "ko",
        "gl": "kr",
        "api_key": SERP_API_KEY
      }

      try:
        search = GoogleSearch(params)
        result = search.get_dict()

        place_info = result.get("place_info", {})
        reviews = result.get("reviews", [])

        korean_reviews = [
          r["snippet"] for r in reviews if re.search(r"[가-힣]", r.get("snippet", ""))
        ]
        translated_reviews = [
          deepl_translate(text, source_lang="KO", target_lang="EN") for text in korean_reviews
        ]

        place = PlaceInfo.objects.create(
          name=name,
          address=address,
          title=place_info.get("title"),
          category=place_info.get("type"),
          description=place_info.get("description"),
          menu_or_ticket_info=place_info.get("attributes", {}),
          price=place_info.get("price"),
          translated_reviews=translated_reviews,
        )

        return GetPlaceInfo(place=place)

      except Exception as e:
        raise Exception(f'SERP API error: {str(e)}')


# ---------------------------
# ✅ Mutation 등록
# ---------------------------
class Mutation(graphene.ObjectType):
  translate_category = TranslateCategory.Field()
  translate_region_to_korean = TranslateRegionToKorean.Field()
  get_place_info = GetPlaceInfo.Field()


# ---------------------------
# 🔍 Query (단일 장소 조회)
# ---------------------------
class Query(graphene.ObjectType):
  place_info_by_name = graphene.Field(
    PlaceInfoType,
    name=graphene.String(required=True),
    address=graphene.String(required=True)
  )

  def resolve_place_info_by_name(self, info, name, address):
    try:
      return PlaceInfo.objects.get(name=name, address=address)
    except PlaceInfo.DoesNotExist:
      return None

