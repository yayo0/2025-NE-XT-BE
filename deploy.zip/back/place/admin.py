from django.contrib import admin
from back.place.models import (
  Category, RegionName,
  CategoryLog, RegionLog,
  PlaceInfo, PlaceLog
)

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
  list_display = ['korean', 'english']
  search_fields = ['korean', 'english']
  ordering = ['korean']


@admin.register(RegionName)
class RegionNameAdmin(admin.ModelAdmin):
  list_display = ['english', 'korean']
  search_fields = ['english', 'korean']
  ordering = ['english']


@admin.register(CategoryLog)
class CategoryLogAdmin(admin.ModelAdmin):
  list_display = ['korean', 'called_at']
  search_fields = ['korean']
  list_filter = ['called_at']
  ordering = ['-called_at']


@admin.register(RegionLog)
class RegionLogAdmin(admin.ModelAdmin):
  list_display = ['english', 'called_at']
  search_fields = ['english']
  list_filter = ['called_at']
  ordering = ['-called_at']


@admin.register(PlaceInfo)
class PlaceInfoAdmin(admin.ModelAdmin):
  list_display = ['name', 'address', 'title', 'category']
  search_fields = ['name', 'address', 'title', 'category']
  list_filter = ['category']
  ordering = ['name']


@admin.register(PlaceLog)
class PlaceLogAdmin(admin.ModelAdmin):
  list_display = ['name', 'address', 'called_at']
  search_fields = ['name', 'address']
  list_filter = ['called_at']
  ordering = ['-called_at']
